function convertCurrency() {
  const from = document.getElementById("from").value;
  const to = document.getElementById("to").value;
  const amount = parseFloat(document.getElementById("amount").value);
  const resultEl = document.getElementById("result");

  if (isNaN(amount) || amount <= 0) {
    resultEl.textContent = "Fadlan geli qadar sax ah.";
    return;
  }

  let rate = 1;
  if (from === "slsh" && to === "usd") {
    rate = 0.00057;
  } else if (from === "usd" && to === "slsh") {
    rate = 1750;
  }

  const result = amount * rate;
  resultEl.textContent = `Natiijada: ${result.toFixed(2)} ${to.toUpperCase()}`;
}

function startChat() {
  window.open("https://wa.me/252634569444", "_blank");
}
